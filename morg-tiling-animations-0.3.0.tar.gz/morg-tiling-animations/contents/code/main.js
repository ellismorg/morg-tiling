// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 Ellis Morgan (@ellismorg)
// Compositor transforms: application geometry is never changed by this effect.
function geometry(r) { return {x:r.x,y:r.y,width:r.width,height:r.height}; }
function valid(r) { return r && isFinite(r.x) && isFinite(r.y) && isFinite(r.width) && isFinite(r.height) && r.width>0 && r.height>0; }
function equal(a,b) { return a.x===b.x && a.y===b.y && a.width===b.width && a.height===b.height; }
function pair(x,y) { return {value1:x,value2:y}; }
function Motion(env) {
    this.env=env;this.states=[];this.dragging=[];this.maximized=[];this.suppressed=[];this.configure();
}
Motion.prototype.configure=function() {
    this.clear();
    var n=Number(this.env.readConfig('Duration',180));
    this.duration=this.env.animationTime(Math.max(0,Math.min(1000,isFinite(n)?n:180)));
    this.enabled=this.env.readConfig('Enabled',true);
};
Motion.prototype.index=function(w) {for(var i=0;i<this.states.length;++i) if(this.states[i].w===w) return i;return -1;};
Motion.prototype.cancel=function(w) {
    var i=this.index(w);if(i<0)return;
    var state=this.states.splice(i,1)[0];this.env.cancel(state.ids);
};
Motion.prototype.clear=function() {
    var self=this;this.states.splice(0).forEach(function(s) {self.env.cancel(s.ids);});
};
Motion.prototype.stateChange=function(w) {
    this.cancel(w);this.suppressed=this.suppressed.filter(function(s){return s.w!==w;});
    this.suppressed.push({w:w,until:this.env.now()+this.env.animationTime(500)});
};
Motion.prototype.eligible=function(w) {
    var now=this.env.now();this.suppressed=this.suppressed.filter(function(s){return s.until>now;});
    return this.enabled && this.duration>0 && w && w.normalWindow && !w.deleted && !w.minimized &&
        !w.fullScreen && !w.desktopWindow && !w.dock && !w.outline && !w.popupWindow &&
        !w.move && !w.resize && this.dragging.indexOf(w)<0 &&
        w.visible!==false && w.onCurrentDesktop!==false && w.onCurrentActivity!==false &&
        this.maximized.indexOf(w)<0 && !this.suppressed.some(function(s){return s.w===w;}) && !this.env.fullscreenEffect();
};
Motion.prototype.visual=function(state) {
    var t=Math.max(0,Math.min(1,(this.env.now()-state.start)/state.duration));
    var eased=1-Math.pow(1-t,3),r={};
    ['x','y','width','height'].forEach(function(k) {r[k]=state.from[k]+(state.to[k]-state.from[k])*eased;});
    return r;
};
Motion.prototype.changed=function(w,oldGeometry) {
    if(!this.eligible(w)) {this.cancel(w);return;}
    var target=geometry(w.geometry);
    if(!valid(target) || !valid(oldGeometry)) {this.cancel(w);return;}
    if(equal(target,oldGeometry)) return;
    var i=this.index(w),from=i<0?geometry(oldGeometry):this.visual(this.states[i]);
    this.cancel(w);
    if(equal(from,target)) return;
    var ids=this.env.animate({window:w,duration:this.duration,curve:this.env.curve,keepAlive:false,
        animations:[
            {type:this.env.size,from:pair(from.width,from.height),to:pair(target.width,target.height)},
            // Size scales around the center. Translation carries that center from
            // its previous visual position, including monitors at negative coordinates.
            {type:this.env.translation,from:pair(from.x+from.width/2-target.x-target.width/2,
                from.y+from.height/2-target.y-target.height/2),to:pair(0,0)}
        ]});
    this.states.push({w:w,ids:ids,from:from,to:target,start:this.env.now(),duration:this.duration});
};
Motion.prototype.ended=function(w,id) {
    var i=this.index(w);if(i<0)return;
    var ids=this.states[i].ids;ids=ids.filter(function(v) {return String(v)!==String(id);});
    if(ids.length)this.states[i].ids=ids;else this.states.splice(i,1);
};
Motion.prototype.startDrag=function(w) {this.cancel(w);if(this.dragging.indexOf(w)<0)this.dragging.push(w);};
Motion.prototype.finishDrag=function(w) {this.dragging=this.dragging.filter(function(v) {return v!==w;});};
Motion.prototype.maximize=function(w,horizontal,vertical) {
    this.stateChange(w);this.maximized=this.maximized.filter(function(v){return v!==w;});
    if(horizontal || vertical)this.maximized.push(w);
};
Motion.prototype.remove=function(w) {this.cancel(w);this.finishDrag(w);this.suppressed=this.suppressed.filter(function(s){return s.w!==w;});this.maximized=this.maximized.filter(function(v){return v!==w;});};
// Plasma 6.6 moved window signals from EffectsHandler to each EffectWindow.
// Keep the older global-signal path for earlier Plasma 6 installations.
function attachMotion(motion,effects,effect) {
    var watched=[];
    function connect(object,name,callback) {
        if(object[name] && object[name].connect)object[name].connect(callback);
    }
    function watch(w) {
        if(!w.normalWindow || watched.indexOf(w)>=0)return;
        watched.push(w);
        connect(w,'windowFrameGeometryChanged',function(window,old){motion.changed(window,old);});
        connect(w,'windowStartUserMovedResized',function(window){motion.startDrag(window);});
        connect(w,'windowFinishUserMovedResized',function(window){motion.finishDrag(window);});
        connect(w,'minimizedChanged',function(window){motion.cancel(window);});
        connect(w,'windowFullScreenChanged',function(window){motion.stateChange(window);});
        connect(w,'windowMaximizedStateAboutToChange',function(window,h,v){motion.maximize(window,h,v);});
        connect(w,'windowHiddenChanged',function(window){if(!window.visible)motion.cancel(window);});
        connect(w,'windowDesktopsChanged',function(window){motion.cancel(window);});
    }
    if(effects.windowFrameGeometryChanged) {
        connect(effects,'windowFrameGeometryChanged',function(w,old){motion.changed(w,old);});
        connect(effects,'windowStartUserMovedResized',function(w){motion.startDrag(w);});
        connect(effects,'windowFinishUserMovedResized',function(w){motion.finishDrag(w);});
        connect(effects,'minimizedChanged',function(w){motion.cancel(w);});
        connect(effects,'windowFullScreenChanged',function(w){motion.stateChange(w);});
        connect(effects,'windowMaximizedStateAboutToChange',function(w,h,v){motion.maximize(w,h,v);});
        connect(effects,'windowHidden',function(w){motion.cancel(w);});
    } else {
        effects.stackingOrder.forEach(watch);
        connect(effects,'windowAdded',watch);
    }
    connect(effects,'windowClosed',function(w){motion.remove(w);});
    connect(effects,'windowDeleted',function(w){motion.remove(w);watched=watched.filter(function(v){return v!==w;});});
    connect(effects,'activeFullScreenEffectChanged',function(){motion.clear();});
    connect(effects,'desktopChanged',function(){motion.clear();});
    connect(effects,'currentActivityChanged',function(){motion.clear();});
    connect(effect,'animationEnded',function(w,id){motion.ended(w,id);});
    connect(effect,'configChanged',function(){motion.configure();});
}
if(typeof effects!=='undefined') {
    var motion=new Motion({readConfig:function(k,d){return effect.readConfig(k,d);},animationTime:animationTime,
        now:function(){return Date.now();},animate:animate,cancel:cancel,curve:QEasingCurve.OutCubic,
        size:Effect.Size,translation:Effect.Translation,fullscreenEffect:function(){return !!effects.hasActiveFullScreenEffect;}});
    attachMotion(motion,effects,effect);
    print('Morg Tiling Animations: Runtime 0.3.0 loaded; smooth movement and resize.');
}
if(typeof module!=='undefined') module.exports={Motion:Motion,attachMotion:attachMotion};
